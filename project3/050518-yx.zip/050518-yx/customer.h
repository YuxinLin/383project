#ifndef CUSTOMER
#define CUSTOMER

// Customer struct: consists of the customer id and the arrival time for each customer
struct customer{
	
	// Customer ID
	char customer_id[2];

	// Arrival time of customer
	int arrival_time; 
};

typedef struct customer customer;

/**
 * The function of GenerateCustomers is to creates an array of customers
 * @param queue points to where customers should be stored
 * @param length indicate the length of queue to create
 */
void GenerateCustomers(customer** queue, int length);

/**
 * The function of PrintCustomers is to print a list of customers
 * @param list is lists of customers to print
 * @param length is the length of list
 */
void PrintCustomers(customer* list, int length);

int NUM_OF_CUSTOMERS; // Total number of customers

#endif
