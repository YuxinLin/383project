#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "shared.h"
#include "seller.h"


void* SellSeats(void* seat_seller){
	// Wait for seat access then unlock 
	while(!start) pthread_cond_wait(&cond, &seat_access);
	pthread_mutex_unlock(&seat_access);
	seller* seat_seller_s = (seller*) seat_seller;

	time_t increased;
	time(&increased);
	// Loop through the queue of customers
   	for (int i = 0; i < NUM_OF_CUSTOMERS; i++)  {
    	time(&increased);
    	int current_time_min = (int) difftime(increased, start_time) / 60;    
    	int current_time_sec = (int) difftime(increased, start_time) % 60;
		while(current_time_sec < seat_seller_s->start_queue->arrival_time && filled_seats < TOTAL_SEATS){
			sleep(1);   // Sell for 1 minute
			time(&increased);
			current_time_sec = (int) difftime(increased, start_time) % 60;
		}
		printf("\nCurrent Time: %1d:%02d\n", current_time_min, current_time_sec);
		char current_customer[2];
 		current_customer[1] = seat_seller_s->start_queue->customer_id[1]; 
 		current_customer[0] = seat_seller_s->start_queue->customer_id[0];
 		printf("\nCustomer %c%c of Seller %c%c arrives", seat_seller_s->start_queue->customer_id[0], seat_seller_s->start_queue->customer_id[1], 
			seat_seller_s->name[0],
			seat_seller_s->name[1]);

		if (seat_seller_s->sales_price == 1) {
			// L seller
			printf("\nCustomer %c%c of Seller %c%c being served\n", current_customer[0], current_customer[1], (*seat_seller_s).name[0], (*seat_seller_s).name[1]);

			sleep((rand() % 4) + 4); // Sell for 4,5,6 or 7 minutes
			pthread_mutex_lock(&seat_access);
			// Sell seat starting with the back of row 10 and work towards the front
			for(int i = 396; i > 0; i -= 4){
				if(*(seat_map + i) == (char) 45){ 
					totalL_sold++; 
					
                    time(&increased);
                    int aftertime = (int) difftime(increased, start_time);
					
					*(seat_map + i) = (*seat_seller_s).name[0];
					*(seat_map + i + 1) = (*seat_seller_s).name[1];
					//TODO: ADD SLOT FOR CUSTOMER
					*(seat_map + i + 2) = current_customer[0];
					*(seat_map + i + 3) = current_customer[1]; 	
					filled_seats++;				
					PrintSeats();
					if(filled_seats >= TOTAL_SEATS) PrintStats();

					printf("\nContinue: %1d:%02d\n\n", aftertime / 60, aftertime % 60);
					printf("\nCustomer %c%c of seller %c%c purchased a ticket at %1d:%02d\n", current_customer[0], current_customer[1],
						(*seat_seller_s).name[0], (*seat_seller_s).name[1], aftertime / 60, aftertime % 60);
					seat_seller_s->start_queue++;
					break;
				}
			}

		} else if (seat_seller_s->sales_price == 2) {
			// M seller
			printf("Customer %c%c of Seller %c%c being served\n", current_customer[0], current_customer[1], (*seat_seller_s).name[0], 
				(*seat_seller_s).name[1]);

			sleep((rand() % 3) + 2); // Sell for 2,3 or 4 minutes
			pthread_mutex_lock(&seat_access); 
			// Sell seat starting with row 5
			int start_index = 160;
			int seat_not_sold = 1;

			do {
				if (*(seat_map + start_index) == (char) 45) {
					totalM_sold++; 
                    time(&increased);
                    int aftertime = (int) difftime(increased, start_time);
					
					*(seat_map + start_index) = (*seat_seller_s).name[0];
					*(seat_map + start_index + 1) = (*seat_seller_s).name[1];
					*(seat_map + start_index + 2) = current_customer[0];
					*(seat_map + start_index + 3) = current_customer[1];
					seat_seller_s->start_queue++;
					seat_not_sold = 0; //seat sold
					filled_seats++;
					PrintSeats();
					if(filled_seats >= TOTAL_SEATS) PrintStats();

					printf("\nContinue: %1d:%02d\n\n", aftertime / 60, aftertime % 60);
					printf("Customer %c%c of seller %c%c purchased a ticket at %1d:%02d \n", current_customer[0], current_customer[1],
						(*seat_seller_s).name[0], (*seat_seller_s).name[1], aftertime / 60, aftertime % 60);
				}

				start_index += 4; // Increment by 4 in index

				/*
				 * Switching between the row with the order of 5->6->4->7->3->8->2->9->1->10 
				 * Index will hit next row after the end of current row sold out
				 * For example: after row 5 sold out, the index will hit the beginning of row 6. 6 is the right order so we don't switch.
				 * After row 6 sold out, the index will hit the beginning of row 7, so we set the index back to the beginning of row 4
				 * According the order, after the end of each row, when hit the next row, switch to beginning of the right row.
				 */
				if (start_index == 240) {
					start_index = 120;
				} else if (start_index == 160) { 
					start_index = 240;
				} else if (start_index == 280) { 
					start_index = 80; 
				} else if (start_index == 120) { 
					start_index = 280;
				} else if (start_index == 320) { 
					start_index = 40;
				} else if (start_index == 80) { 
					start_index = 320;
				} else if (start_index == 360) { 
					start_index = 0;
				} else if (start_index == 40) { 
					start_index = 360;
				}
			} while(seat_not_sold);
		
		} else if (seat_seller_s->sales_price == 3) {
			// H Seller
			printf("Customer %c%c of Seller %c%c being served\n", current_customer[0], current_customer[1], (*seat_seller_s).name[0], 
				(*seat_seller_s).name[1]);
			sleep((rand() % 1) + 1); // Sell for 1 or 2 minutes
			pthread_mutex_lock(&seat_access); 
			// Sell seat starting with the front of row 1 then continue towards the back
			for(int i = 0; i < (TOTAL_SEATS * 4); i += 4){
				if(*(seat_map + i) == (char) 45){
					totalH_sold++; 

                    time(&increased);
                    int aftertime = (int) difftime(increased, start_time);

            		*(seat_map + i) = (*seat_seller_s).name[0];
					*(seat_map + i + 1) = (*seat_seller_s).name[1];
					*(seat_map + i + 2) = current_customer[0];
					*(seat_map + i + 3) = current_customer[1];
					seat_seller_s->start_queue++;
					filled_seats++;
					PrintSeats();
					if(filled_seats >= TOTAL_SEATS) PrintStats();

					printf("\n....%1d:%02d\n\n", aftertime / 60, aftertime % 60);
					printf("Customer %c%c of seller %c%c purchased a ticket at %1d:%02d \n", current_customer[0], current_customer[1],
						(*seat_seller_s).name[0], (*seat_seller_s).name[1], aftertime / 60, aftertime % 60);
					break;
				}
			}
		}

		pthread_mutex_unlock(&seat_access);
	}
	
	pthread_exit(NULL);
}

void PrintSeats(){
	printf("\n\n");
	for(int i = 0; i < (TOTAL_SEATS * 4); i += 4){
		printf("| %c%c%c%c ", seat_map[i], seat_map[i + 1], seat_map[i + 2], seat_map[i + 3]);
		if (i == 36 || i == 76 || i == 116 || i == 156 || i == 196 || i == 236 ||
			i == 276 || i == 316 || i == 356|| i == 396) {
			printf("|\n");
		}
	}
	printf("\n\n");
}

void PrintStats() {
	int total_customers = (NUM_OF_CUSTOMERS * 10);
	printf("\nTotal seats sold: %d", filled_seats);
	printf("\nTotal L seats sold: %d", totalL_sold);
	printf("\nTotal M seats sold: %d", totalM_sold);
	printf("\nTotal H seats sold: %d", totalH_sold);
	printf("\nTotal customers turned away: %d", total_customers - totalL_sold - totalM_sold - totalH_sold);
	printf("\n");
	exit(0); // Program finishes
}
