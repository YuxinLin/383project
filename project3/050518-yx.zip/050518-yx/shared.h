#ifndef SHARED
#define SHARED
#include "pthread.h"
#include <stdbool.h>
#include <time.h>
#include <sys/time.h>

// Total Number of seats that can be sold
#define TOTAL_SEATS 100	
// Total minutes to sell
#define MAX_MINUTES 60 

#define NUM_OF_H_SELLERS 1
#define NUM_OF_M_SELLERS 3
#define NUM_OF_L_SELLERS 6


struct itimerval sellerTimer;

// Restricts access to seats
pthread_mutex_t seat_access; 

pthread_cond_t cond;

// Starting time of ticket sell
time_t start_time;

// Counts how many seats are filled - semaphore
int filled_seats; 

// Simulate the map for seats
char* seat_map; 

bool start; 

// Terminal input variables of custumers number, 5, 10 or 15. - default 15 if there is no input.
int NUM_OF_CUSTOMERS;

// variable to record total tickets for L, M, H seller sold seperately
int totalL_sold;
int totalM_sold;
int totalH_sold;

#endif