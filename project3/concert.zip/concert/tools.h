//
//  tools.h
//  concert
//
//  Created by gladet on 5/1/18.
//  Copyright © 2018 gladet. All rights reserved.
//

#ifndef tools_h
#define tools_h

int randomInteger(int minimum, int maximum);

#endif /* tools_h */
