#ifndef SELLER
#define SELLER

#include "customer.h"

///Seller struct consists of the sellers name, sales price - not used, and the beginning of the queue for customers
struct seller{
	///name consist of seller price e.g. H and the other 2 characters depending on number of seller
	char name[2];

	///1 = L; 2 = M; 3 = H - not currently used
	int sales_price;

	/// Start of customer queue
	customer* start_queue;
};

typedef struct seller seller;

/**
 * print_sellers prints a list of - their name and their sales price
 * @param list   list of sellers
 * @param length the number of sellers
 */
//void print_sellers(seller* list, int length);

/**
 * SellSeats function to run in threads that will simulate a seller selling tickets to customers in queue
 * @param seat_seller pinter to seller
 */
void* SellSeats(void* seat_seller);

/**
 * PrintSeats() prints the seat slots
 */
void PrintSeats();

/**
 * PrintStats() when all seats are taken
 */
void PrintStats();
#endif
