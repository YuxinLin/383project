#ifndef CUSTOMER
#define CUSTOMER


struct customer{
	// Time of arrival to seller
	int arrival_time; 
	// Customer ID
	char customer_id[2];
};

typedef struct customer customer;

/**
 * GenerateCustomers creates an array of customers
 * @param queue  pointer to where customers should be stored
 * @param length length of queue to create
 */
void GenerateCustomers(customer** queue, int length);

/**
 * PrintCustomers prints a list of customers
 * @param list   list of customers to print
 * @param length length of list
 */
void PrintCustomers(customer* list, int length);

int NUM_OF_CUSTOMERS; // Total number of customers

#endif
