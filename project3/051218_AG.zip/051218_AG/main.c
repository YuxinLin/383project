#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <sys/time.h>
#include <signal.h>
#include "seller.h"
#include "customer.h"
#include "shared.h"
#include "algorithms.h"


#define MINUTES 60 

struct itimerval sellerTimer;

void wake_up(){
	pthread_mutex_lock(&seat_access);
	start = true;
	pthread_cond_broadcast(&cond);
	pthread_mutex_unlock(&seat_access);
}

void TimerHandler();

int main(int argc, char *argv[]){

	if(argc < 2) {
        NUM_OF_CUSTOMERS = 15; // default customer size
        printf("\nNo N Given. Using default size N = 15\n\n");
    } else {
        NUM_OF_CUSTOMERS= atoi(argv[1]);
        printf("\nNumber of customers : %d\n\n", NUM_OF_CUSTOMERS);
    }

	// Initilize total sell counts for L, M and H sellers
	totalL_sold = 0;
	totalM_sold = 0;
	totalH_sold = 0;

	//Initilization of variables
	int seed = time(NULL);
	srand(seed);
	start = false;

	// Set timer to exit at 60 minutes
    sellerTimer.it_value.tv_sec = MAX_MINUTES;
    setitimer(ITIMER_REAL, &sellerTimer, NULL);
    time(&start_time);

	time_t current_time; // type calender time
    time(&current_time);
    int sec = (int) difftime(current_time, start_time);

	seat_map = malloc(TOTAL_SEATS * (sizeof(char) * 4)); //100 seats can store 4 each seat
 	memset(seat_map, 45, TOTAL_SEATS * (sizeof(char) * 4));
	seller* h_sellers = malloc(sizeof(seller) * NUM_OF_H_SELLERS);//create h_sellers
	seller* m_sellers = malloc(sizeof(seller) * NUM_OF_M_SELLERS);//create m_sellers
	seller* l_sellers = malloc(sizeof(seller) * NUM_OF_L_SELLERS);//create l_sellers
	filled_seats = 0;

	//Setting and threads
	seat_access = (pthread_mutex_t) PTHREAD_MUTEX_INITIALIZER;
	cond = (pthread_cond_t) PTHREAD_COND_INITIALIZER;
	pthread_t h_seller_thread;
	pthread_t m_sellers_thread[3]; 
	pthread_t l_sellers_thread[6]; 

	//For the future broadcast call to restart threads

	// Populate high seller
	for(int i = 0; i < NUM_OF_H_SELLERS; i++){
        h_sellers[i].name[0] = 'H';
        h_sellers[i].name[1] = (char)(i + '0');   // seller id
		
		GenerateCustomers(&(h_sellers[i].start_queue), NUM_OF_CUSTOMERS);//create constomers for H sellers
		h_sellers[i].sales_price = 3;
	}

	//Populate all medium sellers
	for(int i = 0; i < NUM_OF_M_SELLERS; i++){
        m_sellers[i].name[0] = 'M';
        m_sellers[i].name[1] = (char)(i + '0');

		GenerateCustomers(&(m_sellers[i].start_queue), NUM_OF_CUSTOMERS);//create constomers for M sellers
		m_sellers[i].sales_price = 2;
	}

	// Populate all low sellers
	for(int i = 0; i < NUM_OF_L_SELLERS; i++){
        l_sellers[i].name[0] = 'L';
        l_sellers[i].name[1] = (char)(i + '0');
		GenerateCustomers(&(l_sellers[i].start_queue), NUM_OF_CUSTOMERS); //create constomers for L sellers
		l_sellers[i].sales_price = 1;
	}


    printf("\n-----------QUEUE H seller-----------\n");
	PrintCustomers(h_sellers[0].start_queue, NUM_OF_CUSTOMERS);

    printf("\n---------QUEUE 1ST M seller---------\n");
	PrintCustomers(m_sellers[0].start_queue, NUM_OF_CUSTOMERS);

    printf("\n---------QUEUE 2ND M seller---------\n");
	PrintCustomers(m_sellers[1].start_queue, NUM_OF_CUSTOMERS);

    printf("\n---------QUEUE 3RD M seller---------\n");
	PrintCustomers(m_sellers[2].start_queue, NUM_OF_CUSTOMERS);

    printf("\n---------QUEUE 1ST L seller---------\n");
	PrintCustomers(l_sellers[0].start_queue, NUM_OF_CUSTOMERS);

    printf("\n---------QUEUE 2ND L seller---------\n");
	PrintCustomers(l_sellers[1].start_queue, NUM_OF_CUSTOMERS);

    printf("\n---------QUEUE 3RD L seller---------\n");
	PrintCustomers(l_sellers[2].start_queue, NUM_OF_CUSTOMERS);

    printf("\n---------QUEUE 4TH L seller---------\n");
	PrintCustomers(l_sellers[3].start_queue, NUM_OF_CUSTOMERS);

    printf("\n---------QUEUE 5TH L seller---------\n");
	PrintCustomers(l_sellers[4].start_queue, NUM_OF_CUSTOMERS);

    printf("\n---------QUEUE 6TH L seller---------\n");
	PrintCustomers(l_sellers[5].start_queue, NUM_OF_CUSTOMERS);

    printf("\nStart Time: %1d:%02d\n", (int)(sec / 60), (int)(sec % 60)); // Print initial time stamp

    // Create seller H thread
    pthread_create(&h_seller_thread, NULL, SellSeats, h_sellers);
    
    // Create seller M threads
	for(int i = 0; i < NUM_OF_M_SELLERS; i++){ 
		// arguments(structure, NULL, function that runs in thread, argument to SellSeats function)
		pthread_create(&(m_sellers_thread[i]), NULL, SellSeats, (void*) &m_sellers[i]);
	}
	// Create seller L threads
	for(int i = 0; i < NUM_OF_L_SELLERS; i++){
		pthread_create(&(l_sellers_thread[i]), NULL, SellSeats, (void*) &l_sellers[i]);
	}
	
	wake_up();
    signal(SIGALRM, TimerHandler); // Set signal to listen for when time hits 60 seconds, then call TimerHandler function

	//join all threads
	pthread_join(h_seller_thread, NULL);
	for(int i = 0; i < NUM_OF_L_SELLERS; i++){
		pthread_join(l_sellers_thread[i], NULL);
	}
	for(int i = 0; i < NUM_OF_M_SELLERS; i++){
		pthread_join(m_sellers_thread[i], NULL);
	}
	return 0;
}

void TimerHandler(int signal){
	PrintStats();
}
