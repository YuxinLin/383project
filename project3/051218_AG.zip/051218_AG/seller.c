#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "shared.h"
#include "seller.h"


void* SellSeats(void* seat_seller){
	// Wait for seat access then unlock 
	while(!start) pthread_cond_wait(&cond, &seat_access);
	pthread_mutex_unlock(&seat_access);
	seller* seat_seller_s = (seller*) seat_seller;

	time_t increased;
	time(&increased);
	// Loop through the queue
   	for (int i = 0; i < NUM_OF_CUSTOMERS; i++)  {
    	time(&increased);
    	int current_time_min = (int) difftime(increased, start_time) / 60;    
    	int current_time_sec = (int) difftime(increased, start_time) % 60;
		while(current_time_sec < seat_seller_s->start_queue->arrival_time && filled_seats < TOTAL_SEATS){
			sleep(1);   // Sell for 1 minute
			time(&increased);
			current_time_sec = (int) difftime(increased, start_time) % 60;
		}
		printf("\nCurrent Time: %1d:%02d\n", current_time_min, current_time_sec);
		char current_customer[2];
 		current_customer[1] = seat_seller_s->start_queue->customer_id[1]; 
 		current_customer[0] = seat_seller_s->start_queue->customer_id[0];
 		printf("\nCustomer %c%c of Seller %c%c arrives", seat_seller_s->start_queue->customer_id[0], seat_seller_s->start_queue->customer_id[1], 
			seat_seller_s->name[0],
			seat_seller_s->name[1]);


		if (seat_seller_s->sales_price == 1) {
			// L seller
			printf("\nCustomer %c%c of Seller %c%c being served\n", current_customer[0], current_customer[1], (*seat_seller_s).name[0], (*seat_seller_s).name[1]);

			sleep((rand() % 4) + 4); // Sell for 4,5,6 or 7 minutes
			pthread_mutex_lock(&seat_access); // bad idea to have multiple locks??
			// Sell seat starting with row 10 and work towards the front
			for(int i = 396; i > 0; i -= 4){
				if(*(seat_map + i) == (char) 45){ // (char) 45 = '-'
					totalL_sold++; // Add to L sold count
					
                    time(&increased);
                    int aftertime = (int) difftime(increased, start_time);
					
					*(seat_map + i) = (*seat_seller_s).name[0];
					*(seat_map + i + 1) = (*seat_seller_s).name[1];
					//TODO: ADD SLOT FOR CUSTOMER
					*(seat_map + i + 2) = current_customer[0];
					*(seat_map + i + 3) = current_customer[1]; 	
					filled_seats++;				
					PrintSeats();
					if(filled_seats >= TOTAL_SEATS) PrintStats();

					printf("\nContinue: %1d:%02d\n\n", aftertime / 60, aftertime % 60);
					printf("\nCustomer %c%c of seller %c%c purchased a ticket at %1d:%02d\n", current_customer[0], current_customer[1],
						(*seat_seller_s).name[0], (*seat_seller_s).name[1], aftertime / 60, aftertime % 60);
					seat_seller_s->start_queue++;
					break;
				}
			}

		} else if (seat_seller_s->sales_price == 2) {
			// M seller
			printf("Customer %c%c of Seller %c%c being served\n", current_customer[0], current_customer[1], (*seat_seller_s).name[0], 
				(*seat_seller_s).name[1]);

			sleep((rand() % 3) + 2); // Sell for 2,3 or 4 minutes
			pthread_mutex_lock(&seat_access); 
			// Sell seat starting with row 5 then 6 then 4 then 7
			int start_index = 160;
			int seat_not_sold = 1;

			do {
				if (*(seat_map + start_index) == (char) 45) {
					totalM_sold++; // Add to M sold count

                    time(&increased);
                    int aftertime = (int) difftime(increased, start_time);
					
					*(seat_map + start_index) = (*seat_seller_s).name[0];
					*(seat_map + start_index + 1) = (*seat_seller_s).name[1];
					*(seat_map + start_index + 2) = current_customer[0];
					*(seat_map + start_index + 3) = current_customer[1];
					seat_seller_s->start_queue++;
					seat_not_sold = 0; // Seat now sold
					filled_seats++;
					PrintSeats();
					if(filled_seats >= TOTAL_SEATS) PrintStats();

					printf("\nContinue: %1d:%02d\n\n", aftertime / 60, aftertime % 60);
					printf("Customer %c%c of seller %c%c purchased a ticket at %1d:%02d \n", current_customer[0], current_customer[1],
						(*seat_seller_s).name[0], (*seat_seller_s).name[1], aftertime / 60, aftertime % 60);
				}

				start_index += 4; // Increment by 4 in index
				// Switching for 5->6->4->7->3->8->2 -> 9->1->10 
				if (start_index == 240) { // Hit 7 after end of 6, go back to row 4
					start_index = 120; // Index of row 4
				} else if (start_index == 160) { // Hit row 5 after end of 4, go to row 7
					start_index = 240;
				} else if (start_index == 280) { // hit row 8 after end of 7, go to 3
					start_index = 80; 
				} else if (start_index == 120) { // Hit row 4 after end of 3, go to 8
					start_index = 280;
				} else if (start_index == 320) { // Hit row 9 after end of 8, go to 2
					start_index = 40;
				} else if (start_index == 80) { // Hit row 3 after end of 2, go to 9
					start_index = 320;
				} else if (start_index == 360) { // Hit row 10 after 9, go to 1
					start_index = 0;
				} else if (start_index == 40) { // Hit row 2 after 1, go to 10
					start_index = 360;
				}
			} while (seat_not_sold);
		
		} else if (seat_seller_s->sales_price == 3) {
			// H Seller sales_price = 3

			printf("Customer %c%c of Seller %c%c being served\n", current_customer[0], current_customer[1], (*seat_seller_s).name[0], 
				(*seat_seller_s).name[1]);
			sleep((rand() % 1) + 1); // Sell for 1 or 2 minutes
			pthread_mutex_lock(&seat_access); 
			// Sell seat starting with row 1 then worl towards the front
			for(int i = 0; i < (TOTAL_SEATS * 4); i += 4){
				if(*(seat_map + i) == (char) 45){
					totalH_sold++; // Add to H sold count

                    time(&increased);
                    int aftertime = (int) difftime(increased, start_time);

            		*(seat_map + i) = (*seat_seller_s).name[0];
					*(seat_map + i + 1) = (*seat_seller_s).name[1];
					*(seat_map + i + 2) = current_customer[0];
					*(seat_map + i + 3) = current_customer[1];
					seat_seller_s->start_queue++;
					filled_seats++;
					PrintSeats();
					if(filled_seats >= TOTAL_SEATS) PrintStats();

					printf("\n....%1d:%02d\n\n", aftertime / 60, aftertime % 60);
					printf("Customer %c%c of seller %c%c purchased a ticket at %1d:%02d \n", current_customer[0], current_customer[1],
						(*seat_seller_s).name[0], (*seat_seller_s).name[1], aftertime / 60, aftertime % 60);
					break;
				}
			}
		}

		pthread_mutex_unlock(&seat_access);
	}
	
	pthread_exit(NULL);
}

void PrintSeats(){
	printf("\n\n");
	for(int i = 0; i < (TOTAL_SEATS * 4); i += 4){
		printf("| %c%c%c%c ", seat_map[i], seat_map[i + 1], seat_map[i + 2], seat_map[i + 3]);
		if (i == 36 || i == 76 || i == 116 || i == 156 || i == 196 || i == 236 ||
			i == 276 || i == 316 || i == 356|| i == 396) {
			printf("|\n");
		}
	}
	printf("\n\n");
}

void PrintStats() {
	int total_customers = (NUM_OF_CUSTOMERS * 10);
	printf("\nTotal seats sold: %d", filled_seats);
	printf("\nTotal L seats sold: %d", totalL_sold);
	printf("\nTotal M seats sold: %d", totalM_sold);
	printf("\nTotal H seats sold: %d", totalH_sold);
	printf("\nTotal customers turned away: %d", total_customers - totalL_sold - totalM_sold - totalH_sold);
	printf("\n");
	exit(0); // Program finishes
}
