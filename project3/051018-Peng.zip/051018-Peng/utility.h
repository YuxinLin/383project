#ifndef UTILITY
#define UTILITY

/**
 * The function of Sort is to sort objects from smallest to largest. Objects must have an integer for comparison
 * @param start_obj is the beginning of the array containing the list of objects
 * @param int_comp is the pointer to the first integer contained in the object. this is the integer to compare
 * @param obj_size is the size of each object/struct in the array
 * @param length is the total amount of objects in the array
 */
void Sort(void* start_obj, int* int_comp, int obj_size, int length);

/**
 * The function of Swap is to swaps 2 objects utilizing memcpy and memmove.
 * @param obj_a is the pointer to first object - must be the start of the object
 * @param obj_b is the pointer to the second object - must be start of the object
 * @param size_a is the size of object a - MUST BE SAME SIZE AS OBJECT B
 * @param size_b is the size of object b - MUST BE SAME SIZE AS OBJECT A
 */
static void Swap(void* obj_a, void* obj_b, int size_a, int size_b);

/**
 * The function of SortRec is recursive call from sort function. Uses quick sort to sort objects. It is static so it can only be called from algorithms.c
 * @param start_obj is the beginning of the array containing the list of objects
 * @param int_comp  is the pointer to the first integer contained in the object. this is the integer to compare
 * @param obj_size  is the size of each object/struct in the array
 * @param length is total amount of objects in the array
 */
static void SortRec(void* start_obj, int* int_comp, int obj_size, int length);

#endif
