#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "customer.h"
#include "utility.h"

void GenerateCustomers(customer** queue, int length){
	*queue = malloc(sizeof(customer) * length);
	for(int i = 0; i < length; i++){
		(*queue)[i].arrival_time = (rand() % 59) + 1;  
	}
	Sort(*queue, &((*queue)[0].arrival_time), sizeof(customer), length);
	for(int i = 0; i < length; i++){
		(*queue)[i].customer_id[0] = '0';
		(*queue)[i].customer_id[1] = (i + 1) + '0';
		if(i >= 9){
			(*queue)[i].customer_id[0] = (int) (i + 1) / 10 + '0';
			(*queue)[i].customer_id[1] = ((i + 1) % 10) + '0';

		}
	}
	return;
}

void PrintCustomers(customer* list, int length){
	for(int i = 0; i < length; i++){
		printf("customer id: %c%c  | arrival time: %d\n", list[i].customer_id[0], list[i].customer_id[1], list[i].arrival_time);
	}
}
