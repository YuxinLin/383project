#ifndef SELLER
#define SELLER

#include "customer.h"

// Seller struct: consists of the sellers name, sales price of ticket and the beginning of the queue for customers
struct seller{
	// name consist of seller's priority and number of the seller.
	char name[2];

	// L = 1; M = 2; H = 3. sales_price used to distinguish the ticket selled by which seller.
	int sales_price;

	// Start of customer queue
	customer* start_queue;
};

typedef struct seller seller;

/**
 * The function of SellSeats simulate a seller sells tickets to customer in queue which runs in threads.
 * @param seat_seller pointer to seller
 */
void* SellSeats(void* seat_seller);

/**
 * The function of PrintSeats() is to print the seat slots
 */
void PrintSeats();

/**
 * The function of PrintStats() is to print result & final status of ticket sells for sellers when all seats are taken
 */
void PrintStats();
#endif
