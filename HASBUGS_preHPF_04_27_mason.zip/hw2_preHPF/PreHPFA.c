#include <stdio.h>
#include <stdlib.h>
#include "Sorter.h"
#include "Calculation.h"
#include "HPFA.h"
#include "PreHPFA.h"
#define TRUE 1 //add header to store define variables

float preAverageTAT(struct process jobs_list[], int size) {
	float total_tat = 0.0;
	int num_finished_process = 0;
	for(int i = 0; i < size; i++) {
		if(jobs_list[i].end_time > 0) { //[i] finished
			num_finished_process++;
			//total_tat += (jobs_list[i].actual_start_time + jobs_list[i].service_time - jobs_list[i].arrival_time);
			total_tat += (jobs_list[i].end_time - jobs_list[i].arrival_time);
		}
	}
	return num_finished_process > 0 ? total_tat / num_finished_process : 0;
}

//waiting time
float preAverageWT(struct process jobs_list[], int size) {
	float total_wait_time = 0.0;
	int num_finished_process = 0;
	for(int i = 0; i < size; i++) {
		if(jobs_list[i].end_time > 0) { //[i] finished
			num_finished_process++;
			//total_wait_time += (jobs_list[i].actual_start_time - jobs_list[i].arrival_time);
			//total_wait_time += (jobs_list[i].actual_start_time + jobs_list[i].service_time - jobs_list[i].arrival_time - jobs_list[i].service_time);
			total_wait_time += (jobs_list[i].end_time - jobs_list[i].arrival_time - jobs_list[i].service_time);
		}
	}
	return num_finished_process > 0 ? total_wait_time / num_finished_process : 0;
}

//response time
float preAverageRT(struct process jobs_list[], int size) {
	float total_response_time = 0.0;
	int num_finished_process = 0;
	for(int i = 0; i < size; i++) {
		if(jobs_list[i].end_time > 0) { //[i] finished
			num_finished_process++;
			total_response_time += (jobs_list[i].actual_start_time - jobs_list[i].arrival_time);
		}
	}
	return num_finished_process > 0 ? total_response_time / num_finished_process : 0;
}

void PreHPF(struct process* plist){
	int numberOfProcessCompleted = 0;
	char* arrayHPFOrder = malloc(sizeof(char) * CHAR_ARRAYMAX); //Allocate enough to leave spaces for last process to finish
	memset(arrayHPFOrder, 32, sizeof(char) * CHAR_ARRAYMAX);
	int quanta = 0;

	/**
	Initializing the sizes,indexes and 4 priority queues. 1 is highest priority->4 lowest
	**/
	int size1 = findSize(plist,1); int index1 = 0; int runningIndex1=index1;
	int size2 = findSize(plist,2); int index2 = 0; int runningIndex2=index2;
	int size3 = findSize(plist,3); int index3 = 0; int runningIndex3=index3;
	int size4 = findSize(plist,4); int index4 = 0; int runningIndex4=index4;
	struct process* queue1 = malloc(sizeof(struct process)*size1);
	struct process* queue2 = malloc(sizeof(struct process)*size2);
	struct process* queue3 = malloc(sizeof(struct process)*size3);
	struct process* queue4 = malloc(sizeof(struct process)*size4);
	float* service_time1 = malloc(sizeof(float)*size1);
	float* service_time2 = malloc(sizeof(float)*size2);
	float* service_time3 = malloc(sizeof(float)*size3);
	float* service_time4 = malloc(sizeof(float)*size4);


	/**
	Since the plist is sorted in terms of priority, I used findSize above to find how many of each priorities there are.
	Then I put them in their own queues using offsets of size1 to size4
	**/
	for(int i=0;i<size1;i++){
		queue1[i]=plist[i];
	}
	int k=0;
	for(int i=size1;i<size1+size2;i++){
		queue2[k++]=plist[i];
	}
	k=0;
	for(int i=size1+size2;i<size1+size2+size3;i++){
		queue3[k++]=plist[i];
	}
	k=0;
	for(int i=size1+size2+size3;i<NUM_PROCESS;i++){
		queue4[k++]=plist[i];
	}

	/**
	Sorting the priority queues based on their arrival times now, so I have 4 priority queues, each sorted by arrival time
	**/
	mergeSort(&queue1,0,size1-1);
	mergeSort(&queue2,0,size2-1);
	mergeSort(&queue3,0,size3-1);
	mergeSort(&queue4,0,size4-1);

	for(int i=0;i<size1;i++){
		service_time1[i]=queue1[i].service_time;
	}
	for(int i=0;i<size2;i++){
		service_time2[i]=queue2[i].service_time;
	}	
	for(int i=0;i<size3;i++){
		service_time3[i]=queue3[i].service_time;
	}	
	for(int i=0;i<size4;i++){
		service_time4[i]=queue4[i].service_time;
	}

	for(int i=0; i<NUM_PROCESS && quanta<MAX_QUANTA;i++){
		if(index1<size1 && queue1[index1].arrival_time<=quanta){
			while(queue1[runningIndex1].service_time>0){
				if(queue1[runningIndex1].actual_start_time<=0){
					queue1[runningIndex1].actual_start_time=quanta;
					printf("1first time seeing %c\n",queue1[runningIndex1].name);
				}
				queue1[runningIndex1].service_time-=1;
				if(queue1[runningIndex1].service_time<=0){
					queue1[runningIndex1].end_time=quanta;
					numberOfProcessCompleted++;
				}
				arrayHPFOrder[quanta++] = queue1[runningIndex1].name;
				printf("1putting %c into quanta: %d   \n",queue1[runningIndex1].name, quanta-1);
				while(index1<size1 && queue1[index1].service_time<=0){
					index1++;
				}
				
				if(runningIndex1+1==size1 || (runningIndex1<size1 && queue1[runningIndex1+1].arrival_time > quanta)){
					runningIndex1=index1;
				}
				else{
					runningIndex1++;
				}
			}
		}
		else if(index2<size2 && queue2[index2].arrival_time<=quanta){
			while((index1<size1 && queue1[index1].arrival_time>=quanta) && queue2[runningIndex2].service_time>0){
				if(queue2[runningIndex2].actual_start_time<=0){
					queue2[runningIndex2].actual_start_time=quanta;
				}
				queue2[runningIndex2].service_time-=1;
				if(queue2[runningIndex2].service_time<=0){
					queue2[runningIndex2].end_time=quanta;
					numberOfProcessCompleted++;
				}
				arrayHPFOrder[quanta++] = queue2[runningIndex2].name;
				printf("2putting %c into quanta: %d   \n",queue1[runningIndex1].name, quanta-1);
				while(index2<size2 && queue2[index2].service_time<=0){
					index2++;
				}
				
				if(runningIndex2+1==size2 || (runningIndex2<size2 && queue2[runningIndex2+1].arrival_time > quanta)){
					runningIndex2=index2;
				}
				else{
					runningIndex2++;
				}
			}
		}
		else if(index3<size3 && queue3[index3].arrival_time<=quanta){
			while((index1<size1 && queue1[index1].arrival_time>=quanta) && (index2<size2 && queue2[index2].arrival_time>=quanta) && queue3[runningIndex3].service_time>0){
				if(queue3[runningIndex3].actual_start_time<=0){
					queue3[runningIndex3].actual_start_time=quanta;
				}
				queue3[runningIndex3].service_time-=1;
				if(queue3[runningIndex3].service_time<=0){
					queue3[runningIndex3].end_time=quanta;
					numberOfProcessCompleted++;
				}
				arrayHPFOrder[quanta++] = queue3[runningIndex3].name;
				printf("3putting %c into quanta: %d   \n",queue1[runningIndex1].name, quanta-1);
				while(index3<size3 && queue3[index3].service_time<=0){
					index3++;
				}
				
				if(runningIndex3+1==size3 || (runningIndex3<size3 && queue3[runningIndex3+1].arrival_time > quanta)){
					runningIndex3=index3;
				}
				else{
					runningIndex3++;
				}
			}
		}
		else if(index4<size4 && queue4[index4].arrival_time<=quanta){
			while((index1<size1 && queue1[index1].arrival_time>=quanta) && (index2<size2 && queue2[index2].arrival_time>=quanta) && (index3<size3 && queue3[index3].arrival_time>=quanta) && queue4[runningIndex4].service_time>0){
				if(queue4[runningIndex4].actual_start_time<=0){
					queue4[runningIndex4].actual_start_time=quanta;
				}
				queue4[runningIndex4].service_time-=1;
				if(queue4[runningIndex4].service_time<=0){
					queue4[runningIndex4].end_time=quanta;
					numberOfProcessCompleted++;
				}
				arrayHPFOrder[quanta++] = queue4[runningIndex4].name;
				printf("4putting %c into quanta: %d   \n",queue1[runningIndex1].name, quanta-1);
				while(index4<size4 && queue4[index4].service_time<=0){
					index4++;
				}
				
				if(runningIndex4+1==size4 || (runningIndex4<size4 && queue4[runningIndex4+1].arrival_time > quanta)){
					runningIndex4=index4;
				}
				else{
					runningIndex4++;
				}
			}
		}
		else{
			arrayHPFOrder[quanta++]='-';

			printf("putting '-' into quanta: %d   \n", quanta-1);
		}
	}

	int completed1=0; int completed2=0; int completed3=0; int completed4=0;
	for(int i=0;i<size1;i++){
		if(queue1[i].service_time<=0){
			completed1++;
		}
		queue1[i].service_time = service_time1[i];
	}
	for(int i=0;i<size2;i++){
		if(queue2[i].service_time<=0){
			completed2++;
		}
		queue2[i].service_time = service_time2[i];
	}	
	for(int i=0;i<size3;i++){
		if(queue3[i].service_time<=0){
			completed3++;
		}
		queue3[i].service_time = service_time3[i];
	}	
	for(int i=0;i<size4;i++){
		if(queue4[i].service_time<=0){
			completed4++;
		}
		queue4[i].service_time = service_time4[i];
	}
	/**
	Printing the time chart of 100+ quantas. I have it set at 150 max entries in arrayHPFOrder, while maxquanta is 100
	**/
	printf("\n\n");
	for(int i=0;i<CHAR_ARRAYMAX;i++){
		printf("%d:%c \n",i,arrayHPFOrder[i]);
	}
	printf("\n\n");

	/**
	Puts back all the entries in the priority queues back into the plist, so that we can calculate the total statistics for all entries
	Ideally, I should have made the queues double pointer arrays to access the plist without needing to put it back, but too late. 
	**/
	int j=0;k=0;int l=0;int m=0;
	for(int i=0;i<NUM_PROCESS;i++){
		if(j<size1){
			plist[i]=queue1[j++];
		}
		else if(k<size2){
			plist[i]=queue2[k++];
		}
		else if(l<size3){
			plist[i]=queue3[l++];
		}
		else if(m<size4){
			plist[i]=queue4[m++];
		}
	}
	/**
	Printing values
	**/
	printf("Priority Queue 1 Averages:\n");
	printf("Average turnaround time: %.2f\n", (completed1==0)?0 : preAverageTAT(queue1,size1));
	printf("Average waiting time: %.2f\n", (completed1==0)?0 : preAverageWT(queue1, size1));
	printf("Average response time: %.2f\n", (completed1==0)?0 : preAverageRT(queue1, size1));
	printf("Throughput: %d\n", completed1);
	printf("\n");

	printf("Priority Queue 2 Averages:\n");
	printf("Average turnaround time: %.2f\n", (completed2==0)?0 : preAverageTAT(queue2,size2));
	printf("Average waiting time: %.2f\n", (completed2==0)?0 : preAverageWT(queue2,size2));
	printf("Average response time: %.2f\n", (completed2==0)?0 : preAverageRT(queue2,size2));
	printf("Throughput: %d\n", completed2);

	printf("\n");
	printf("Priority Queue 3 Averages:\n");
	printf("Average turnaround time: %.2f\n", (completed3==0)?0 : preAverageTAT(queue3,size3));
	printf("Average waiting time: %.2f\n", (completed3==0)?0 : preAverageWT(queue3, size3));
	printf("Average response time: %.2f\n", (completed3==0)?0 : preAverageRT(queue3, size3));
	printf("Throughput: %d\n", completed3);

	printf("\n");
	printf("Priority Queue 4 Averages:\n");
	printf("Average turnaround time: %.2f\n", (completed4==0)?0 : preAverageTAT(queue4,size4));
	printf("Average waiting time: %.2f\n", (completed4==0)?0 : preAverageWT(queue4, size4));
	printf("Average response time: %.2f\n", (completed4==0)?0 : preAverageRT(queue4, size4));
	printf("Throughput: %d\n", completed4);


	printf("\n");
	printf("Overall Averages:\n");
	printf("Average turnaround time: %.2f\n", preAverageTAT(plist,NUM_PROCESS));
	printf("Average waiting time: %.2f\n", preAverageWT(plist,NUM_PROCESS));
	printf("Average response time: %.2f\n", preAverageRT(plist,NUM_PROCESS));
	printf("Throughput: %d\n", numberOfProcessCompleted);
}