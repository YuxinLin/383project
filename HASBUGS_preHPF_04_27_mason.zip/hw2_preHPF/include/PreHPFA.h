#ifndef PREHPFA_H
#define PREHPFA_H

float preAverageTAT(struct process jobs_list[], int size);
float preAverageWT(struct process jobs_list[], int size);
float preAverageRT(struct process jobs_list[], int size);
void PreHPF(struct process* o_plist);

#endif // PREHPFA_H
