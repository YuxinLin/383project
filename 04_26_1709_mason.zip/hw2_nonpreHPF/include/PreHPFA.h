#ifndef PREHPFA_H
#define PREHPFA_H

void PreHPFA(struct process* o_plist);

#endif // PREHPFA_H
