#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "process_producer.h"
#include "RR.h"
#include "HPFA.h"
#include "FCFS.h"

void RoundRobin(struct process* o_plist){
    int counter_char_array = 0; //index of output array
    int process_completed = 0;
    
    int counter_queue_end = 0; //point to the end of run process queue
    int index_queue = 0;
    
    int quanta = 0;
    int head = 0; //point to the head of waitting for response queue
    
    int end = 0;
    float total_waiting_time = 0;
    float total_turnaround_time = 0;
    float total_response_time = 0;
    
    char* arrayRROrder = malloc(sizeof(char) * CHAR_ARRAYMAX);
    memset(arrayRROrder, 32, sizeof(char) * CHAR_ARRAYMAX);
    
    //copy the process list of original process list
    struct process* plist = malloc(sizeof(struct process)* NUM_PROCESS);
    memcpy(plist, o_plist, sizeof(struct process) * NUM_PROCESS);
    
    //sort by Arrival Time, function definition in HPFA
    mergeSort(&plist, 0, NUM_PROCESS - 1);
    
    if(plist[0].arrival_time == 0.0){
        quanta = 0; //start the first process in quanta 0
        plist[0].actual_start_time = 0;
    }
    else{
        quanta = plist[0].arrival_time + 1; //start the first process in the next quanta of its arrival time
        plist[0].actual_start_time = quanta; //record the actrual start time of the first process
    }
    
    while(counter_char_array < quanta){
        arrayRROrder[counter_char_array] = '-';
        counter_char_array++;
        //coutinue waiting until the first process start to execute
    }
    
    
    while(1){
        
        if(quanta >= 100 && end == 1) break; //after 100 quanta, run all the process in the queue until finish all
        
        if(quanta < 100){
            //update waiting queue. after 100 quanta, no more new arrival process adding to the queue
            for(int i = head; i < NUM_PROCESS; i++){
                if(plist[i].arrival_time <= quanta){
                    counter_queue_end++;
                }
                else{
                    head = i;
                    break;
                }
            }
        }
        
        //count unfinished process number of the current queue
        for(int j = 0; j < counter_queue_end; j++){
            if(plist[j].end_time == -1){
                end = 0;
            }
            else{
                end = 1;
            }
        }
        
        //ignore the finished process in the queue
        while(plist[index_queue].end_time != -1){
            index_queue++;
        }
        
        
        if(index_queue != counter_queue_end){
            arrayRROrder[counter_char_array] = plist[index_queue].name;
            counter_char_array++;
            plist[index_queue].service_time--;
            if(plist[index_queue].actual_start_time == -1){
                plist[index_queue].actual_start_time = quanta;
            }
            if(plist[index_queue].service_time <= 0){
                plist[index_queue].end_time = quanta;
                
                //add the process to finished joblist
                process_completed += 1;
                
                total_waiting_time += plist[index_queue].end_time - plist[index_queue].arrival_time - plist[index_queue].service_time;
                total_turnaround_time += plist[index_queue].end_time - plist[index_queue].arrival_time;
                total_response_time += plist[index_queue].actual_start_time - plist[index_queue].arrival_time;
            }
            quanta++;
            index_queue++;
            //if index run to the queue end, start from the first process again
            if(index_queue == counter_queue_end){
                index_queue = 0;
            }
        }
        else{
            index_queue = 0;
            if(end == 1){
                //if quanta < 100 and there are no more unfinished process, waiting
                arrayRROrder[counter_char_array] = '-';
                counter_char_array++;
                quanta++;
            }
        }
        
    }
    
    printCharTable(arrayRROrder, quanta);
    
    printf("\n");
    printf("Average turnaround time: %.2f\n", total_turnaround_time/process_completed);
    printf("Average response time: %.2f\n", total_response_time/process_completed);
    printf("Average waiting time: %.2f\n", total_waiting_time/process_completed);
    printf("Throughput in 100 quanta: %.2f\n", 100.0*process_completed/quanta);
    free(plist);
}
