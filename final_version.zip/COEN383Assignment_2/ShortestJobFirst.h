#ifndef ShortestJobFirst
#define ShortestJobFirst

//char* shortestJobFirst(struct process* o_plist);
void shortestJobFirst(struct process* o_plist);

#endif