#ifndef HPFA
#define HPFA

void nonpreHPF(struct process* plist);

#endif
