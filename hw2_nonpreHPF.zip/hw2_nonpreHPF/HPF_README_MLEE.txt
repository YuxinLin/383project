4/26/18 Mason Lee

Updating for HPF

Changes: 

-random header includes were not working, so I changed them around. 
-did not touch sorter, calculations, or any other implementations

Main.c:
	-commented out some parts
	-changed the name of getOrderHPFA to nonpreHPF
	-only touched the main part, not the other functions

HPFA.h:
	-changed name of function to nonpreHPF

HPFA.c:
	-changed all of it to fit this implementation
	-has a merge sort function inside
	-also has non-preemptive equations for the output statistics

process_producer.h:
	-changed the NUM_PROCESS definition to 50

process_producer.c:
	-changed the following to include more characters
	char alphabet[50] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890abcdefghijklmn";