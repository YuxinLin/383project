#include <stdio.h>
#include <stdlib.h>
#include "process_producer.h"
#include "Calculation.h"
#include "ShortestJobFirst.h"
#include <string.h>
#include "Sorter.h"
#include <stdbool.h>

/*
 *revision history
 *rewrite round robin
 *end time = curr quantum -> NOT curr quantum - 1
 */

#define SERVICE_TIME_UPPER_BOUND 10

/*void PrintProcess(struct process curr_job){
	printf("%c: Arrival Time: %.1f Start Time: %2d Service Time: %.1f End Time: %.1f Turnaround Time: %.1f Response Time: %.1f\n", curr_job.name, curr_job.arrival_time, curr_job.actual_start_time, curr_job.service_time, curr_job.actual_start_time + curr_job.service_time, curr_job.actual_start_time + curr_job.service_time - curr_job.arrival_time, curr_job.actual_start_time - curr_job.arrival_time);
 }*/

//jobs_list is an array of all the processes with info about arrival time and service time.
void RoundRobin(struct process* jobs_list)
{
	int curr_quantum = 0; //1; //0; -> actually the end time of curr quantum [0, 1] -> 1
	int num_finished_jobs = 0;
	
	char* time_chart = malloc(sizeof(char) * CHAR_ARRAYMAX); // Allocate enough to leave spaces for last process to finish
																													 //int time_chart_idx = 0;
	memset(time_chart, 32, sizeof(char) * CHAR_ARRAYMAX); //check memset -> 32 -> space
	struct process* jobs_queue = malloc(sizeof(struct process) * NUM_PROCESS); //initialize arrays with size of NUM_PROCESS
	memcpy(jobs_queue, jobs_list, (sizeof(struct process) * NUM_PROCESS)); //copy processes into newArrivalArray
	SortBy(&jobs_queue, 0); //sort by arrival time
													//PrintProcessList(jobs_queue); //print list of processes
	
	bool finished[NUM_PROCESS]; //a bool array to indicate the job is finished or not
	for(int i = 0; i < NUM_PROCESS; i++) { //init -> false
		finished[i] = false;
	}
	float remain_time[NUM_PROCESS];
	for(int i = 0; i < NUM_PROCESS; i++) { //init -> service time
		remain_time[i] = jobs_queue[i].service_time;
	}
	int curr_queue_idx = 0; //init idx to 0 -> first job in queue
	int num_arrived_undone_jobs = 0;
	
	bool done = false; //indicate simulation done or not
	while(!done) {
		//find the first undone process
		if(jobs_queue[curr_queue_idx].arrival_time > curr_quantum) { //curr job not arrive yet
			if(num_arrived_undone_jobs > 0) {
				//there is at least one arrived and undone job at curr quantum -> arrived before curr job
				// find out the first arrived and undone job
				int i = 0;
				while(i < curr_queue_idx && (finished[i] || jobs_queue[i].arrival_time > curr_quantum)) {
					i++;
				}
				//i == curr_queue_idx || (!finished[i] && [i].arrival <= curr quantum
				curr_queue_idx = i;
			} else { //no arrived and undone job at curr quantum -> just incre quanta until can run curr job
				//increment quantum until first job arrived
				while(curr_quantum < jobs_queue[curr_queue_idx].arrival_time) {
					time_chart[curr_quantum++] = '-'; //update time chart
				}
				//curr_quantum >= queue[curr_queue_idx].arrival -> at least one process arrived and not done yet
			}
		} //else -> curr job arrived already -> just run it
		//the job to run found
		if(jobs_queue[curr_queue_idx].actual_start_time < 0) {
			//this job not start yet -> set the actual start time
			jobs_queue[curr_queue_idx].actual_start_time = curr_quantum;
			num_arrived_undone_jobs++; //increment num_arrived_undone_jobs
		}
		//float actual_end_time = curr_quantum + jobs_queue[shortest_idx].service_time; //might not be an integer
		char curr_job_name = jobs_queue[curr_queue_idx].name;
		//print curr job name to record -> time chart
		time_chart[curr_quantum++] = curr_job_name;//increment curr_quantum
		//decrement remain time
		remain_time[curr_queue_idx] =  remain_time[curr_queue_idx] - 1.0;
		if(remain_time[curr_queue_idx] <= 0) { //this job is done
			jobs_queue[curr_queue_idx].end_time = curr_quantum; //set end time
			//jobs_queue[curr_queue_idx].end_time = curr_quantum - 1.0; //set end time
			finished[curr_queue_idx] = true; //update finished
			num_finished_jobs++; //increment num of finished jobs
			//print curr job when finished
			//PrintProcessPreemptive(jobs_queue[curr_queue_idx]);
			num_arrived_undone_jobs--; //decrement num because curr job is done
		}
		if((curr_quantum >= MAX_QUANTA - 1 && num_arrived_undone_jobs == 0) || num_finished_jobs == NUM_PROCESS) {
		//if(curr_quantum >= MAX_QUANTA - 1 || num_finished_jobs == NUM_PROCESS) {
			done = true; //max quanta reached or no more unstarted job to run
		}
		curr_queue_idx = (curr_queue_idx + 1) % NUM_PROCESS; //move idx to next job in the queue
		//find next undone job
		int i = 0;
		while(i < NUM_PROCESS && (finished[curr_queue_idx]
				|| (curr_quantum >= MAX_QUANTA - 1 && jobs_queue[curr_queue_idx].actual_start_time < 0))) {
			//skip finished jobs as well as unstarted job after 100 quanta
		//while(i < NUM_PROCESS && finished[curr_queue_idx]) { //skip finished jobs
			i++;
			curr_queue_idx = (curr_queue_idx + 1) % NUM_PROCESS; //move idx to next job in the queue
		}
		//i == NUM_PROCESS || !finished[curr_queue_idx] -> an undone job found
	}
	/*
	for (int i = 0; i < CHAR_ARRAYMAX; i++) {
		printf("%c", time_chart[i]);
	}
	*/
	//printf("\n");
	
	printCharTable(time_chart, curr_quantum);
	
	printf("\nAverage turnaround time: %.2f\n", AverageTATPre(jobs_queue, NUM_PROCESS));
	printf("Average response time: %.2f\n", AverageRT(jobs_queue, NUM_PROCESS));
	printf("Average waiting time: %.2f\n", AverageWTPre(jobs_queue, NUM_PROCESS));
	printf("Throughput in 100 quanta: %.2f\n", 100.0 * num_finished_jobs / curr_quantum);
	
	free(jobs_queue); //don't forget to free the memory space for malloc
	free(time_chart);
	
	//return time_chart; //why return it?
}
