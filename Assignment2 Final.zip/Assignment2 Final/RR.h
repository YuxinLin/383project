#ifndef RR
#define RR

#include "process_producer.h"
#include "RR.h"
#include "HPFA.h"
#include "FCFS.h"

void RoundRobin(struct process* jobs_list);

#endif